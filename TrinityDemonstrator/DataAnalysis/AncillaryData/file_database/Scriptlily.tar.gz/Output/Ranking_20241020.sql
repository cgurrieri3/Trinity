INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T05:52:02.739_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T05:54:21.671_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T06:22:41.576_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T06:24:21.510_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T06:26:21.510_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-20T06:28:21.510_0000.root','1','Moon');
