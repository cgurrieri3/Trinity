INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-16T03:08:58.009_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-16T03:10:38.943_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-16T03:12:38.945_0000.root','1','Moon');
