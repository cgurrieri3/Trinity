INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-07-06T05:58:15.173_0000.root','0','Weather');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-07-06T05:59:14.110_0000.root','0','Weather');
