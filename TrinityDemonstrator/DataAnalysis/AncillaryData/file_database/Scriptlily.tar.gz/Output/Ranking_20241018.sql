INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-18T03:28:45.806_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-18T03:30:26.737_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-18T05:32:46.181_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-18T05:34:19.042_0000.root','1','Moon');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2024-10-18T05:36:19.044_0000.root','1','Moon');
