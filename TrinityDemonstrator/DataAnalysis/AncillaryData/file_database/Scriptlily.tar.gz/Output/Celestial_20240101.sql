INSERT INTO CelestialInfo(Filename, sunAzimuth, sunAltitude, moonAzimuth, moonAltitude, moonIllumination) VALUES ('20240101T00:00:00.00_FolderEmpty','237.27','3.07','9.65','-38.96','0.7');
