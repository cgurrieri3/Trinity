INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('20250512T00:00:00.00_FolderEmpty','00','Moon');
