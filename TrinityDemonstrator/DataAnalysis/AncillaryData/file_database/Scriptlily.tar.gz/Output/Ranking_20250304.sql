INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2025-03-04T06:20:56.492_0000.root','1','Weather');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2025-03-04T06:22:04.424_0000.root','1','Weather');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2025-03-04T06:24:04.423_0000.root','1','Weather');
INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('CoBo0_AsAd0_2025-03-04T06:26:04.423_0000.root','1','Weather');
