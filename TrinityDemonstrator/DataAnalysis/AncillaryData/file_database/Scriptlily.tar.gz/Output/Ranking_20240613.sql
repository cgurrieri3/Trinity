INSERT INTO RankingInfo(Filename, ranking, comments) VALUES ('20240613T00:00:00.00_FolderEmpty','0','Weather');
